package com.example.flutter_soundapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
