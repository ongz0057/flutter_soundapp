import 'package:flutter/material.dart';

class TakeAudio extends StatefulWidget {
  @override
  _TakeAudio createState() => new _TakeAudio();
}

class _TakeAudio extends State<TakeAudio> {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new Scaffold(
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment
                .center, //align buttons in column to center (vertical)
            crossAxisAlignment: CrossAxisAlignment
                .center, // align buttons in column to center (horizontal)
            children: <Widget>[
              FlatButton(
                color: Colors.blue,
                textColor: Colors.white,
                padding: EdgeInsets.all(16.0),
                splashColor: Colors.blueAccent,
                child: Text('Take Image'),
                onPressed: () {
                  print('hi');
                },
              ),
              SizedBox(
                height: 20.0,
                width: double.infinity,
              ),
              FlatButton(
                color: Colors.blue,
                textColor: Colors.white,
                padding: EdgeInsets.all(16.0),
                splashColor: Colors.blueAccent,
                child: Text('Take Audio'),
                onPressed: () {
                  Navigator.pushNamed(context, '/second');
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
