import 'package:flutter/material.dart';
import 'takeSample.dart';
import 'package:flutter_audio_recorder/flutter_audio_recorder.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(
    MaterialApp(
      // Start the app with the "/" named route. In this case, the app starts
// on the FirstScreen widget.
      initialRoute: '/',
      routes: {
// When navigating to the "/" route, build the FirstScreen widget.
        '/': (context) => Homepage(),
// When navigating to the "/second" route, build the SecondScreen widget.
        '/second': (context) => TakeAudio(),
      },
    ),
  );
}

class Homepage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey,
      body: SafeArea(
        //A widget that insets its child by sufficient padding to avoid intrusions by the operating system
        child: Column(
          mainAxisAlignment: MainAxisAlignment
              .center, //align buttons in column to center (vertical)
          crossAxisAlignment: CrossAxisAlignment
              .center, // align buttons in column to center (horizontal)
          children: <Widget>[
            FlatButton(
              color: Colors.blue,
              textColor: Colors.white,
              padding: EdgeInsets.all(16.0),
              splashColor: Colors.blueAccent,
              child: Text('Take Image'),
              onPressed: () {
                print('hi');
              },
            ),
            SizedBox(
              height: 20.0,
              width: double.infinity,
            ),
            FlatButton(
              color: Colors.blue,
              textColor: Colors.white,
              padding: EdgeInsets.all(16.0),
              splashColor: Colors.blueAccent,
              child: Text('Take Audio'),
              onPressed: () {
                Navigator.pushNamed(context, '/second');
              },
            )
          ],
        ),
      ),
      appBar: AppBar(
        title: Text('SoundApp'),
        backgroundColor: Colors.blueGrey[700],
      ),
    );
  }
}
